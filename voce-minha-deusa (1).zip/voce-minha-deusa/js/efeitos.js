document.addEventListener('DOMContentLoaded', () => {
    const audio = document.getElementById('audio-player');
    const btnPlayPause = document.getElementById('btn-play-pause');
    const iconePlay = document.getElementById('icone-play');
    const tempoAtual = document.getElementById('tempo-atual');
    const tempoTotal = document.getElementById('tempo-total');

    if (!audio || !btnPlayPause) return;

    function formatarTempo(segundos) {
        if (!Number.isFinite(segundos)) return '0:00';
        const min = Math.floor(segundos / 60);
        const seg = Math.floor(segundos % 60);
        return `${min}:${seg < 10 ? '0' : ''}${seg}`;
    }

    audio.addEventListener('loadedmetadata', () => {
        tempoTotal.textContent = formatarTempo(audio.duration);
    });

    audio.addEventListener('timeupdate', () => {
        tempoAtual.textContent = formatarTempo(audio.currentTime);
    });

    btnPlayPause.addEventListener('click', async () => {
        if (audio.paused) {
            try {
                await audio.play();
                iconePlay.textContent = '❚❚ Pausar';
            } catch (erro) {
                console.error('Não foi possível reproduzir o áudio:', erro);
            }
        } else {
            audio.pause();
            iconePlay.textContent = '▶ Reproduzir';
        }
    });

    audio.addEventListener('pause', () => {
        if (!audio.ended) iconePlay.textContent = '▶ Reproduzir';
    });

    audio.addEventListener('ended', () => {
        iconePlay.textContent = '▶ Reproduzir';
        audio.currentTime = 0;
    });
});
